package com.aurora.store.data.model

enum class NetworkStatus {
    AVAILABLE,
    LOST
}
