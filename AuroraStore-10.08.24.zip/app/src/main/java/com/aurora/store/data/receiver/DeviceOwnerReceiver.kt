package com.aurora.store.data.receiver

import android.app.admin.DeviceAdminReceiver

class DeviceOwnerReceiver : DeviceAdminReceiver()
